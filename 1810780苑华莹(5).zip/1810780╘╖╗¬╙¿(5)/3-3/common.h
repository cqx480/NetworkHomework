
#define SYN_SEND 0
#define SYN_RCVD 1
#define ESTABLISHED 2

//�涨flag����λ 
#define SYN 0
#define ACK 1
#define PSH 2
#define RST 3
#define URG 4
#define FIN 5
#define ACK_GROUP 6
#define END 7


#define HELLO
#define NORMAL
#define GOODBYE
